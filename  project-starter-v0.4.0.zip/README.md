# project-starter

[![ci](https://github.com/alexandrosm/project-starter/actions/workflows/ci.yml/badge.svg)](https://github.com/alexandrosm/project-starter/actions/workflows/ci.yml)

One word from any shell to a running AI coding agent inside a fresh, git-initialized project.

```powershell
start my-app build a snake game
```

creates the project folder, runs `git init`, opens a **new Windows Terminal tab**, and launches your agent with `build a snake game` as its initial prompt.

## Install

**PowerShell** — one command:

```powershell
irm https://raw.githubusercontent.com/alexandrosm/project-starter/main/bootstrap.ps1 | iex
```

**bash / zsh (Git Bash, WSL)** — one command:

```bash
curl -fsSL https://raw.githubusercontent.com/alexandrosm/project-starter/main/bootstrap.sh | bash
```

**cmd.exe** — one command:

```bat
powershell -NoProfile -ExecutionPolicy Bypass -Command "irm https://raw.githubusercontent.com/alexandrosm/project-starter/main/bootstrap.ps1 | iex"
```

All three download the repo to `~\.project-starter` and wire up that shell's face (the PowerShell bootstrap also wires bash when it detects it). Re-running any of them updates an existing install. Uninstall per shell: `uninstall.ps1`, `uninstall.sh`, `install-cmd.ps1 -Remove` from the installed folder.

## Shells

| Shell | Entry | Notes |
|---|---|---|
| PowerShell 5.1 / 7+ | native function | `-Yolo` / `-Here`; stays in project dir after `-Here` sessions |
| bash / zsh (Git Bash, WSL) | sourced shim | `--yolo` / `--here`; cwd not preserved after `--here` (child process) |
| cmd.exe | doskey macro via HKCU AutoRun | **interactive sessions only** — scripted `cmd /c start ...` is untouched |

All three drive one engine (`Start-Project.ps1`), so resume detection, the agent registry, metadata, and pickers behave identically everywhere.

## Usage

| Command | Behavior |
|---|---|
| `start` | Pick an existing project (fzf if installed, else numbered list); shows saved intent + last-active time |
| `start <name>` | Create (or reopen) `<root>\<name>`. Reopening **auto-resumes** with the agent that last ran there |
| `start <name> words...` | Extra words become the agent's initial prompt *and* are saved as the project's intent |
| `start -Agent <name>` / `--agent` | Force the agent for a new project |
| `start -SetDefaultAgent <name>` / `--default-agent` | Persist the default agent (`none` clears) |
| `start ... -Yolo` / `--yolo` | Appends the agent's auto-approval flag (opt-in per invocation) |
| `start ... -Here` / `--here` | Launch in the current window instead of a new tab |
| `start -Doctor` / `--doctor` | Audit tools, agents, config, hooks |

New projects choose their agent in this order: explicit `-Agent` → persisted default → sole installed agent → **interactive picker over installed agents** → omp fallback.

### ⚠️ `-Yolo` safety

`-Yolo` appends each agent's auto-approval flag (e.g. `--approval-mode yolo`, `--dangerously-skip-permissions`). The agent will then **execute commands without asking you**. It is opt-in per invocation by design — never the default — and its effect is limited to the session it flags.

## Resume: how the agent is chosen

Every launch writes `<project>\.ps-project.json`. On reopen:

1. That file's `agent` wins (exact recall).
2. Otherwise fingerprints: `.claude/` or `CLAUDE.md` -> `claude -c`; `.codex/` -> `codex resume --last`; `.gemini/` -> `gemini`.
3. Otherwise omp's own session buckets (`~/.omp/agent/sessions/*-<name>-*`) -> `omp -c`.
4. Default: `omp`.

Known limits: Gemini CLI has no trustworthy resume flag, so it relaunches fresh; Codex cannot take a prompt alongside resume, so extra words are dropped with a warning.

## Agents

Built-in registry: **omp, claude, codex, gemini, aider, opencode, qwen**. Flags marked best-effort carry conservative values (empty `yoloFlags` warns instead of guessing). An optional `agents.json` next to `Start-Project.ps1` merges over the built-ins:

```json
{
  "aider": {
    "continueArgs": ["--resume", "--last"],
    "takesPromptOnContinue": false,
    "yoloFlags": ["--yes-always"]
  },
  "omp": { "continueArgs": ["--continue"] }
}
```

| Key | Meaning | Default |
|---|---|---|
| `continueArgs` | argv used when resuming an existing project | `[]` |
| `takesPromptOnContinue` | may extra words ride along on resume | `true` |
| `yoloFlags` | argv appended by `-Yolo` | `[]` (warns) |

Built-in yolo flags: omp `--approval-mode yolo`, claude `--dangerously-skip-permissions`, codex `--full-auto`, gemini/qwen `--yolo`, aider `--yes-always`.

Run `start -Doctor` to see which agents resolve on your machine and which have complete profiles.

## Per-project metadata

`.ps-project.json` in each project root:

```json
{
  "agent": "omp",
  "intent": "build a snake game",
  "created": "2026-08-23T10:00:00.0000000Z",
  "updated": "2026-08-23T12:30:00.0000000Z"
}
```

Plain JSON, safe to edit or commit-ignore. User config lives separately in `%APPDATA%\project-starter\config.json` (`{"defaultAgent": "..."}`).

## Requirements

Windows. PowerShell 5.1 or 7+ (engine). Optional: Windows Terminal (`wt`) for new-tab launches, `fzf` for the picker, Git Bash for the bash shim, any agent executables you register.

## Development

Clone, then two bundled suites, both stubbed (touch only temp dirs + a redirected config dir):

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File tests\run-tests.ps1              # engine matrix (27 checks)
pwsh       -NoProfile -ExecutionPolicy Bypass -File tests\run-tests-crossshell.ps1   # shims + cmd lifecycle (15 checks)
```

CI runs both suites plus a remote-bootstrap smoke test on `windows-latest` for every push.

Lint gate: PSScriptAnalyzer runs in CI (settings: `tests/PSScriptAnalyzerSettings.psd1`).
